import React from 'react';

const EventListPage = () => {
    return (
        <div>
            <h2>This event list page </h2>
        </div>
    );
};

export default EventListPage;