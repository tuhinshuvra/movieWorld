const EventEntryForm = () => {
    return (
        <div>
            <h2>This is event Entry form</h2>
        </div>
    );
};

export default EventEntryForm;