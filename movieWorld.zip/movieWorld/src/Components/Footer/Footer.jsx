import "./Footer.css"
const Footer = () => {
    return (
        <div className="footerArea  ">
            <div className="container">
                <footer className="py-1 my-1">
                    {/* <ul className="nav justify-content-center border-bottom pb-3 mb-3">
                        <li className="nav-item"><a href="#" className="nav-link px-2 text-muted">Home</a></li>
                        <li className="nav-item"><a href="#" className="nav-link px-2 text-muted">Directory</a></li>
                        <li className="nav-item"><a href="#" className="nav-link px-2 text-muted">News</a></li>
                        <li className="nav-item"><a href="#" className="nav-link px-2 text-muted">About</a></li>
                        <li className="nav-item"><a href="#" className="nav-link px-2 text-muted">Login</a></li>
                    </ul> */}
                    {/* <p className="text-center text-muted">&copy; {new Date().getFullYear()}   Company, Inc</p> */}
                    {/* <hr /> */}

                    {/* <p>© {new Date().getFullYear()} JUBOF. All rights reserved. | Powered by [Your Platform or Technology]</p> */}
                    <div className="d-md-flex justify-content-center">
                        <p className="text-center my-0">© {new Date().getFullYear()} JUBOF. All rights reserved</p>
                        <span className=" mx-3 d-none d-md-block">|</span>
                        <p className=" text-center my-0">
                            Powered by
                            <a className=" text-decoration-none ms-1" href="https://www.techsimpleict.com/" target="_blank" rel="noreferrer">TechSimple ICT</a>
                        </p>
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default Footer;