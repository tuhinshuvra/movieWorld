const configUrl = {
    // BASEURL: "https://ju-bof-server-site.vercel.app"
    BASEURL: "https://jubof-be.vercel.app"
}
export default configUrl;  